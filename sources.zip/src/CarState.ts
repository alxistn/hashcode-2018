enum CarState {
    FREE,
    GOING_TO_DEPARTURE,
    WAITING,
    GOING_TO_ARRIVAL
}

export default CarState;