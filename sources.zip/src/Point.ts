export default class Point {
    
}